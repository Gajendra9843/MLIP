# OBELiX production-structure composition audit

Generated: 2026-07-16T02:19:08.274900+00:00
Option-A spectra audited: 311

## Audit status counts
- PASS: 171
- FAIL_GENERAL_STOICHIOMETRY: 101
- WARN_SHORT_DISTANCE: 13
- FAIL_ELEMENT_SET: 11
- FAIL_LI_STOICHIOMETRY: 11
- WARN_SMALL_STOICHIOMETRY_DEVIATION: 4

## Interpretation rules
- PASS means the production atom counts are proportional to the official OBELiX reduced composition within the configured tolerance.
- FAIL_LI_STOICHIOMETRY means the non-Li framework scales correctly but the Li count does not, consistent with vacancy or partial-occupancy over/under-filling.
- Negative plotted-DOS grid endpoints are not used as stability evidence.
- True instability diagnostics come from phonon_eigen_data.npz mesh frequencies.
- The oxidation-state result is only a feasibility heuristic, not a chemical validation.

## Primary files
- tables/production_structure_composition_audit.csv
- tables/source_to_production_ordering_audit.csv
- tables/spectrum_grid_qc.csv
- tables/eigenfrequency_stability_qc.csv
- tables/regeneration_priority.csv